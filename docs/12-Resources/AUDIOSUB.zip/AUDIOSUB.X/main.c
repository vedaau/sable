/*
 * main.c ? ICS-43434 I�S mic + LED VU meter on PIC18F27Q43
 *
 * Pins:  RB3 = SCK,  RB4 = SD,  RB5 = WS,  RC4 = LED,
 *        RC6 = UART1 TX,  RC7 = UART1 RX (loopback test only)
 *
 * SPI timing fix (compared to original):
 *   The SPI runs continuously from burn-in onward ? never stopped.
 *   The main loop reads one SPI byte per iteration, toggles WS every
 *   4 bytes, and processes a complete sample every 8 bytes.  This
 *   prevents the frame-drift bug where the SPI auto-clocked bytes
 *   that nobody read.  BAUD is slowed to 63 so the per-byte CPU
 *   overhead (~2-7 �s) always fits within one byte time (16 �s).
 *
 * UART loopback test (runs at startup, before SPI):
 *   Jumper RC6 ? RC7.  Sends 12 test bytes and reads them back.
 *   LED: 5 fast blinks = PASS, 1 long blink = FAIL.
 *
 * UART streaming (runs in main loop):
 *   Protocol frame:
 *     [A][Z][from][to][MIC_ON or MICOFF (6 bytes)][Y][B]   (12 bytes total)
 *   Use uart_capture.py on the PC to record and save as WAV.
 *
 * Watches:
 *   g_level_current  ? peak-to-peak amplitude of last 32 frames
 *   g_level_peak     ? highest p-p seen since reset
 *   g_raw_sample     ? latest raw sample
 *   g_word_count     ? frame counter
 *   g_left[0..3]     ? last raw SPI bytes (left channel)
 */

 #include <xc.h>
 #include <stdint.h>
 
 #pragma config RSTOSC = HFINTOSC_64MHZ
 #pragma config WDTE   = OFF
 #pragma config MCLRE  = EXTMCLR
 #pragma config LVP    = ON
 
 #define NOISE_GATE_ON   16000   /* envelope must exceed this to light LED  */
 #define NOISE_GATE_OFF   6000   /* envelope must drop below this to go dark */
 
 /* ?? Class protocol constants ?????????????????????????????????????? */
 #define MSG_PREFIX_0    'A'
 #define MSG_PREFIX_1    'Z'
 #define MSG_SUFFIX_0    'Y'
 #define MSG_SUFFIX_1    'B'
 #define MSG_BROADCAST   'X'
 
 #define TEAM_MEMBER_M   'M'
 #define TEAM_MEMBER_C   'C'
 #define TEAM_MEMBER_A   'A'
 #define TEAM_MEMBER_L   'L'
 #define TEAM_MEMBER_V   'V'
 #define TEAM_MEMBER_K   'K'
 
 #define MY_ID           TEAM_MEMBER_V
 #define DEST_ID         MSG_BROADCAST
 
 
 /* ?? Watch variables ??????????????????????????????????????????????? */
 volatile uint32_t g_level_current = 0;
 volatile uint32_t g_level_peak    = 0;
 volatile int32_t  g_raw_sample    = 0;
 volatile uint32_t g_word_count    = 0;
 volatile uint8_t  g_left[4];
 
 /* ?? Loopback test results ????????????????????????????????????????? */
 volatile uint8_t g_lb_tx       = 0;
 volatile uint8_t g_lb_rx       = 0;
 volatile uint8_t g_lb_match    = 0;
 volatile uint8_t g_lb_mismatch = 0;
 volatile uint8_t g_lb_last_tx  = 0;
 volatile uint8_t g_lb_last_rx  = 0;
 volatile uint8_t g_lb_pass     = 0;
 
 /* ?? Helpers ??????????????????????????????????????????????????????? */
 
 static void pps_unlock(void) { PPSLOCK = 0x55; PPSLOCK = 0xAA; PPSLOCKbits.PPSLOCKED = 0; }
 static void pps_lock(void)   { PPSLOCK = 0x55; PPSLOCK = 0xAA; PPSLOCKbits.PPSLOCKED = 1; }
 
 static void pins_setup(void)
 {
     ANSELB &= (uint8_t)~((1u << 3) | (1u << 4) | (1u << 5));
     ANSELC &= (uint8_t)~((1u << 4) | (1u << 6) | (1u << 7));
 
     TRISBbits.TRISB3 = 0;
     TRISBbits.TRISB4 = 1;
     TRISBbits.TRISB5 = 0;
     LATBbits.LATB5   = 0;
 
     TRISCbits.TRISC4 = 0;
     LATCbits.LATC4   = 0;
     TRISCbits.TRISC6 = 0;
     TRISCbits.TRISC7 = 1;
 
     WPUBbits.WPUB4 = 0;
 
     pps_unlock();
     RB3PPS     = 0x31;
     SPI1SDIPPS = 0x0C;
     SPI1SCKPPS = 0x0B;
     RC4PPS     = 0x00;
     RC6PPS     = 0x20;
     U1RXPPS    = 0x17;
     pps_lock();
 }
 
 static void spi1_setup(void)
 {
     SPI1CON0 = 0;
     SPI1CON0bits.MST   = 1;
     SPI1CON0bits.LSBF  = 0;
     SPI1CON0bits.BMODE = 0;
 
     SPI1CON1 = 0;
     SPI1CON1bits.CKP = 0;
     SPI1CON1bits.CKE = 1;
     SPI1CON1bits.SMP = 0;
 
     SPI1CON2 = 0;
     SPI1CON2bits.TXR = 0;
     SPI1CON2bits.RXR = 1;
 
     SPI1CLK    = 0;
     SPI1BAUD   = 63;        /* slower clock: more CPU headroom per byte */
     SPI1TWIDTH = 0;
 
     SPI1CON0bits.EN = 1;
     SPI1TCNTH = 0xFF;
     SPI1TCNTL = 0xFF;
 }
 
 static inline uint8_t spi1_read_byte(void)
 {
     if (SPI1TCNTH < 0x10) {
         SPI1TCNTH = 0xFF;
         SPI1TCNTL = 0xFF;
     }
     while (!SPI1STATUSbits.RXBF) { ; }
     return SPI1RXB;
 }
 
 static inline int32_t assemble_24bit(uint8_t b0, uint8_t b1, uint8_t b2)
 {
     uint32_t raw = ((uint32_t)b0 << 16) | ((uint32_t)b1 << 8) | b2;
     return (raw & 0x800000UL) ? (int32_t)(raw | 0xFF000000UL) : (int32_t)raw;
 }
 
 /* ?? UART ?????????????????????????????????????????????????????????? */
 
 #define FRAME_SIZE 12
 
static uint8_t tx_buf[FRAME_SIZE];
static uint8_t tx_pos = FRAME_SIZE;

/* ?? UART RX ? TX forwarding ring buffer ?????????????????????????? */
#define FWD_BUF_SIZE 32          /* must be power of 2 */
static uint8_t fwd_buf[FWD_BUF_SIZE];
static uint8_t fwd_head = 0;
static uint8_t fwd_tail = 0;

/* ?? Mic-TX throttle (~0.5 s at ~7 812 frames/s) ?????????????????? */
#define MIC_TX_INTERVAL 15624u
static uint16_t mic_tx_div  = 0;
static uint32_t mic_env_sum = 0;
static uint16_t mic_env_cnt = 0;
 
 static void uart1_setup(void)
 {
     U1CON0 = 0;
     U1CON1 = 0;
     U1CON2 = 0;
 
     U1CON0bits.BRGS = 1;
     U1CON0bits.TXEN = 1;
 
     U1BRGH = 0x06;
     U1BRGL = 0x82;
 
     U1CON1bits.ON = 1;
 }
 
static inline void uart_rx_fwd(void)
{
    while (PIR4bits.U1RXIF) {
        uint8_t next = (fwd_head + 1) & (FWD_BUF_SIZE - 1);
        if (next != fwd_tail) {
            fwd_buf[fwd_head] = U1RXB;
            fwd_head = next;
        } else {
            (void)U1RXB;
        }
    }
}

static inline void uart_poll(void)
{
    if (!PIR4bits.U1TXIF) return;

    if (fwd_tail != fwd_head) {
        U1TXB = fwd_buf[fwd_tail];
        fwd_tail = (fwd_tail + 1) & (FWD_BUF_SIZE - 1);
        return;
    }

    if (tx_pos < FRAME_SIZE)
        U1TXB = tx_buf[tx_pos++];
}
 
 static inline void uart_queue(uint8_t led_on)
 {
     if (tx_pos >= FRAME_SIZE) {
        tx_buf[0]  = MSG_PREFIX_0;
        tx_buf[1]  = MSG_PREFIX_1;
        tx_buf[2]  = MY_ID;
        tx_buf[3]  = DEST_ID;
        if (led_on) {
            tx_buf[4]  = 'M';
            tx_buf[5]  = 'I';
            tx_buf[6]  = 'C';
            tx_buf[7]  = '_';
            tx_buf[8]  = 'O';
            tx_buf[9]  = 'N';
        } else {
            tx_buf[4]  = 'M';
            tx_buf[5]  = 'I';
            tx_buf[6]  = 'C';
            tx_buf[7]  = 'O';
            tx_buf[8]  = 'F';
            tx_buf[9]  = 'F';
        }
        tx_buf[10] = MSG_SUFFIX_0;
        tx_buf[11] = MSG_SUFFIX_1;
         tx_pos = 0;
     }
 }
 
 /* ?? UART loopback test ???????????????????????????????????????????? */
 
 static void uart_loopback_test(void)
 {
     U1CON0bits.RXEN = 1;
 
     while (PIR4bits.U1RXIF)
         (void)U1RXB;
 
    static const uint8_t frame[FRAME_SIZE] = {
        MSG_PREFIX_0, MSG_PREFIX_1,
        MY_ID, DEST_ID,
        'M', 'I', 'C', '_', 'O', 'N',
        MSG_SUFFIX_0, MSG_SUFFIX_1
    };
 
     for (uint8_t i = 0; i < FRAME_SIZE; i++) {
         while (!PIR4bits.U1TXIF) { ; }
         U1TXB = frame[i];
         g_lb_tx++;
         g_lb_last_tx = frame[i];
 
         for (uint32_t t = 0; t < 80000UL; t++) {
             if (PIR4bits.U1RXIF) break;
         }
 
         if (PIR4bits.U1RXIF) {
             uint8_t rx = U1RXB;
             g_lb_rx++;
             g_lb_last_rx = rx;
             if (rx == frame[i]) g_lb_match++;
             else                g_lb_mismatch++;
         }
     }
 
     while (!U1ERRIRbits.TXMTIF) { ; }
 
     g_lb_pass = (g_lb_match == FRAME_SIZE) ? 1 : 0;
     U1CON0bits.RXEN = 0;
 
     if (g_lb_pass) {
         for (uint8_t i = 0; i < 5; i++) {
             LATCbits.LATC4 = 1;
             for (volatile uint32_t d = 0; d < 50000UL; d++) { ; }
             LATCbits.LATC4 = 0;
             for (volatile uint32_t d = 0; d < 50000UL; d++) { ; }
         }
     } else {
         LATCbits.LATC4 = 1;
         for (volatile uint32_t d = 0; d < 500000UL; d++) { ; }
         LATCbits.LATC4 = 0;
     }
 }
 
 /* ?? Main ?????????????????????????????????????????????????????????? */
 
 int main(void)
 {
     OSCFRQ = 0x08;
     while (!OSCCON3bits.ORDY) { ; }
 
     pins_setup();
 
     /* Startup double-blink */
     for (uint8_t i = 0; i < 2; i++) {
         LATCbits.LATC4 = 1;
         for (volatile uint32_t d = 0; d < 200000UL; d++) { ; }
         LATCbits.LATC4 = 0;
         for (volatile uint32_t d = 0; d < 200000UL; d++) { ; }
     }
 
     /* UART loopback test runs BEFORE SPI ? so the mic's clock
        is never interrupted by the loopback delay. */
    uart1_setup();
    uart_loopback_test();

    U1CON0bits.RXEN = 1;          /* re-enable RX for forwarding */

    /* ?? SPI start + burn-in (SPI never stops after this) ???????? */
     spi1_setup();
     uint8_t bcount = 0;
     LATBbits.LATB5 = 0;
 
     for (uint32_t i = 0; i < 64000UL; i++) {
         spi1_read_byte();
         if (++bcount == 4) { bcount = 0; LATBbits.LATB5 ^= 1; }
     }
 
     /* ?? Main loop ?????????????????????????????????????????????????
      *
      *  One SPI byte per iteration ? same tight pattern as burn-in.
      *  WS toggles every 4 bytes.  After every 8 bytes (1 I2S frame),
      *  the sample is assembled and fed to UART + envelope.
      *
      *  fpos tracks position 0-7 within each frame:
      *    0-3: WS=LOW  (left channel) ? bytes 0,1,2 are 24-bit data
      *    4-7: WS=HIGH (right channel) ? discarded
      * ???????????????????????????????????????????????????????????????? */
     int32_t  win_min  = 0x7FFFFFL;
     int32_t  win_max  = -0x800000L;
     uint8_t  win_ctr  = 0;
     uint32_t envelope = 0;
     uint16_t led_hold = 0;
 
     uint8_t fpos = 0;
     uint8_t lb[3];
 
     for (;;) {
         uint8_t b = spi1_read_byte();
 
         if (fpos < 3) lb[fpos] = b;
 
         fpos++;
 
         if (fpos == 4) {
             LATBbits.LATB5 = 1;            /* switch to right channel */
         } else if (fpos == 8) {
             LATBbits.LATB5 = 0;            /* switch back to left     */
             fpos = 0;
 
             /* ?? Complete frame: assemble + stream + envelope ?????? */
             int32_t sample = assemble_24bit(lb[0], lb[1], lb[2]);
             g_raw_sample = sample;
             g_left[0] = lb[0];
             g_left[1] = lb[1];
             g_left[2] = lb[2];
 
             if (sample > win_max) win_max = sample;
             if (sample < win_min) win_min = sample;
 
             if (++win_ctr >= 32) {
                 win_ctr = 0;
                 uint32_t pp = (uint32_t)(win_max - win_min);
 
                 if (pp > envelope) {
                     uint32_t rise = (pp - envelope) >> 1;
                     envelope += (rise > 0) ? rise : 1;
                 } else {
                     uint32_t dec = (envelope >> 3) + 1;
                     envelope = (envelope > dec) ? envelope - dec : 0;
                 }
 
                g_level_current = envelope;
                if (envelope > g_level_peak) g_level_peak = envelope;

                mic_env_sum += envelope;
                mic_env_cnt++;

                win_min =  0x7FFFFFL;
                 win_max = -0x800000L;
             }
 
             if (envelope > NOISE_GATE_ON) {
                 LATCbits.LATC4 = 1;
                 led_hold = 1500;
             } else if (envelope < NOISE_GATE_OFF && led_hold == 0) {
                 LATCbits.LATC4 = 0;
             }
             if (led_hold > 0) led_hold--;
 
            if (++mic_tx_div >= MIC_TX_INTERVAL) {
                mic_tx_div = 0;
                uint32_t avg = mic_env_cnt
                    ? (mic_env_sum / mic_env_cnt) : 0;
                uart_queue(avg > NOISE_GATE_ON);
                mic_env_sum = 0;
                mic_env_cnt = 0;
            }

            g_word_count++;
        }
         
        uart_rx_fwd();
        uart_poll();
     }
 }
 